# 📊 AWS DEPLOYMENT VISUAL GUIDE

## 🏗️ ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────────────┐
│                         YOUR USERS                              │
│         (Web Browser, Android Phone, Admin Dashboard)           │
└─────────────────────────────────────────────────────────────────┘
         │                    │                      │
         │                    │                      │
         ▼                    ▼                      ▼
    ┌─────────┐         ┌──────────┐         ┌──────────────┐
    │  AWS    │         │ AWS      │         │ Google Play  │
    │  S3     │         │ EC2      │         │ Store /      │
    │ (HTTPS) │         │(5000)    │         │ Direct APK   │
    │ Static  │         │ Node.js  │         │              │
    │ Files   │         │ Backend  │         │ Android App  │
    └─────────┘         └──────────┘         └──────────────┘
         │                    │
         │                    │
         │                    ▼
         │              ┌──────────────┐
         │              │ AWS RDS      │
         │              │ PostgreSQL   │
         │              │ (port 5432)  │
         │              └──────────────┘
         │
         └─────────────────────────────────────┐
                                               │
                                    ┌──────────▼──────────┐
                                    │ User's Browser      │
                                    │ Sees Web App        │
                                    └─────────────────────┘
```

---

## 🔄 REQUEST FLOW

### Web Application Flow

```
BROWSER REQUEST
      │
      ▼
┌─────────────────────┐
│ AWS S3 / CloudFront │  ◄─── Serves HTML, CSS, JS
│   Static Content    │
└─────────────────────┘
      │
      ▼
┌─────────────────────┐
│  React App Loads    │  ◄─── User sees app
│  in Browser         │
└─────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  User clicks "Login"                    │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  POST http://EC2_IP:5000/api/auth/login │  ◄─── API Call
│  with username & password               │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  AWS EC2 Instance (Node.js Backend)     │
│  - Validate credentials                 │
│  - Check password hash                  │
│  - Create session                       │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  Query Database                         │
│  SELECT user FROM users WHERE ...       │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  AWS RDS PostgreSQL                     │
│  Returns user data                      │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  Backend sends response                 │
│  {user: {...}, success: true}           │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│  Browser receives response              │
│  Shows patient/admin dashboard          │
└─────────────────────────────────────────┘
```

---

## 📱 MOBILE APP FLOW

```
USER'S PHONE
     │
     ▼
┌────────────────────┐
│ Android Phone      │
│ Settings > Security│
│ Enable Unknown     │
│ Sources            │
└────────────────────┘
     │
     ▼
┌────────────────────┐
│ Download APK File  │  ◄─── From your website/email
│ (mediflow.apk)     │
└────────────────────┘
     │
     ▼
┌────────────────────┐
│ Double-click APK   │
│ Open Install       │
│ Dialog             │
└────────────────────┘
     │
     ▼
┌────────────────────┐
│ Installation       │
│ Progress Bar       │
└────────────────────┘
     │
     ▼
┌────────────────────┐
│ "Install Complete" │
└────────────────────┘
     │
     ▼
┌────────────────────┐
│ Open App           │
│ (Same as web app)  │
│ Login with creds   │
│ Access features    │
└────────────────────┘
```

---

## 📊 AWS COMPONENTS USED

### 1. EC2 (Backend Server)
```
┌─────────────────────────────────────┐
│  AWS EC2 - t3.micro (1 vCPU, 1GB)   │
├─────────────────────────────────────┤
│ Ubuntu 22.04 LTS                    │
│ Node.js 20                          │
│ npm packages                        │
│ Express.js server                   │
│ Running on port 5000                │
│ PM2 process manager                 │
├─────────────────────────────────────┤
│ Cost: $0/month (free tier)          │
│ 750 hours/month included            │
└─────────────────────────────────────┘
```

### 2. RDS (Database)
```
┌─────────────────────────────────────┐
│  AWS RDS - db.t3.micro              │
├─────────────────────────────────────┤
│ PostgreSQL 14                       │
│ 20GB storage                        │
│ Database: mediflow                  │
│ User: admin                         │
│ Tables:                             │
│  - users                            │
│  - treatments                       │
│  - medicines                        │
│  - intake_logs                      │
│  - notifications                    │
├─────────────────────────────────────┤
│ Cost: $0/month (free tier)          │
│ 750 hours/month included            │
│ 20GB storage included               │
└─────────────────────────────────────┘
```

### 3. S3 (Frontend Storage)
```
┌─────────────────────────────────────┐
│  AWS S3 Bucket                      │
├─────────────────────────────────────┤
│ Bucket Name: mediflow-web-[date]    │
│ Region: Same as EC2                 │
│ Contains:                           │
│  - index.html                       │
│  - CSS files                        │
│  - JavaScript bundles               │
│  - Images & assets                  │
│ Static website hosting: ENABLED     │
│ Public access: ALLOWED              │
├─────────────────────────────────────┤
│ Cost: $0/month (free tier)          │
│ 5GB storage included                │
└─────────────────────────────────────┘
```

### 4. Security Groups (Firewalls)
```
EC2 Security Group:
  ├─ SSH (22) from My IP
  ├─ HTTP (80) from 0.0.0.0/0
  ├─ HTTPS (443) from 0.0.0.0/0
  └─ TCP (5000) from 0.0.0.0/0

RDS Security Group:
  ├─ PostgreSQL (5432) from EC2 SG
  └─ SSH (22) from My IP
```

---

## 🔐 SECURITY ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                         INTERNET                            │
└─────────────────────────────────────────────────────────────┘
         │                           │
         │ HTTPS (443)               │ HTTP (5000)
         ▼                           ▼
    ┌─────────────┐            ┌────────────────┐
    │ AWS S3      │            │ AWS EC2        │
    │ (Public)    │            │ (Public IP)    │
    │ Frontend    │            │ Backend API    │
    └─────────────┘            └────────────────┘
         │                           │
         ▼                           │
    ┌──────────────────────────────┐│
    │ AWS VPC (Virtual Private     ││
    │ Cloud)                        ││
    │ Default VPC with security     ││
    │ groups acting as firewalls    ││
    └──────────────────────────────┘│
                                     │
                    ┌────────────────┘
                    ▼
            ┌───────────────────────┐
            │ AWS RDS (Private)     │
            │ PostgreSQL (5432)     │
            │ Only accessible from  │
            │ EC2 security group    │
            └───────────────────────┘
```

---

## 📈 DATA FLOW

### User Registration

```
User enters:
- Full Name
- Email
- Username
- Password (plaintext)
     │
     ▼
Frontend sends to Backend:
POST /api/auth/signup
{
  fullName: "John Doe",
  email: "john@example.com",
  username: "johndoe",
  password: "password123"
}
     │
     ▼
Backend processes:
1. Validate input
2. Hash password with bcrypt
3. Generate UUID for user
4. Create session
     │
     ▼
Database stores:
INSERT INTO users VALUES (
  id: "uuid-123",
  username: "johndoe",
  email: "john@example.com",
  fullName: "John Doe",
  password: "$2b$10$...hashed...",
  role: "patient"
)
     │
     ▼
Backend returns:
{
  id: "uuid-123",
  username: "johndoe",
  email: "john@example.com",
  fullName: "John Doe",
  role: "patient"
}
     │
     ▼
Frontend:
1. Stores session
2. Redirects to dashboard
3. User logged in!
```

---

## 🗄️ DATABASE SCHEMA (Visual)

```
┌─────────────────┐
│     users       │
├─────────────────┤
│ id (PK)         │
│ username        │
│ email           │
│ password_hash   │
│ full_name       │
│ role            │
│ created_at      │
└─────────────────┘
      │ 1:N
      │
      ├─────────────┐
      │             │
      ▼             ▼
  ┌──────────────┐  ┌─────────────────┐
  │ treatments   │  │ notifications   │
  ├──────────────┤  ├─────────────────┤
  │ id (PK)      │  │ id (PK)         │
  │ patient_id   │  │ user_id (FK)    │
  │ name         │  │ title           │
  │ description  │  │ message         │
  │ status       │  │ type            │
  │ start_date   │  │ read            │
  │ end_date     │  │ created_at      │
  │ created_at   │  └─────────────────┘
  └──────────────┘
      │ 1:N
      │
      ▼
  ┌──────────────┐
  │  medicines   │
  ├──────────────┤
  │ id (PK)      │
  │ treatment_id │
  │ name         │
  │ dosage       │
  │ frequency    │
  │ schedule_time│
  │ instructions │
  │ stock        │
  │ created_at   │
  └──────────────┘
      │ 1:N
      │
      ▼
  ┌──────────────┐
  │ intake_logs  │
  ├──────────────┤
  │ id (PK)      │
  │ medicine_id  │
  │ scheduled_at │
  │ taken_at     │
  │ status       │
  │ notes        │
  │ created_at   │
  └──────────────┘
```

---

## 🚀 DEPLOYMENT TIMELINE

```
Time  │ Activity                          │ Status
──────┼───────────────────────────────────┼─────────────
0 min │ Start                             │ ▓░░░░░░░░░
5     │ Create EC2 instance               │ ▓▓░░░░░░░░
10    │ Install Node.js & npm             │ ▓▓▓░░░░░░░
15    │ Upload project files              │ ▓▓▓▓░░░░░░
20    │ Create RDS database               │ ▓▓▓▓▓░░░░░
25    │ Configure backend                 │ ▓▓▓▓▓▓░░░░
30    │ Start backend on EC2              │ ▓▓▓▓▓▓▓░░░
35    │ Build & upload frontend to S3     │ ▓▓▓▓▓▓▓▓░░
40    │ Enable S3 static website          │ ▓▓▓▓▓▓▓▓▓░
45    │ Test backend & frontend           │ ▓▓▓▓▓▓▓▓▓▓ DONE!

Plus 30-45 min for mobile APK build
Plus 2-4 hours for Google Play Store approval (if deploying)
```

---

## 💰 COST CALCULATION

```
Monthly Cost Breakdown (Year 1):

EC2 t3.micro:
  750 hours included free
  Your usage: 24 hrs × 30 days = 720 hours
  → $0

RDS db.t3.micro:
  750 hours included free
  Your usage: 24 hrs × 30 days = 720 hours
  → $0

S3 Storage:
  5 GB included free
  Your usage: ~500 MB (frontend files)
  → $0

Data Transfer:
  1 GB outbound included free
  Your usage: Variable but usually <1 GB
  → $0

TOTAL: $0/month ✅

Year 2+ (after free tier):
EC2: ~$5/month
RDS: ~$15/month
S3: ~$0.10/month
Data: ~$0.09/GB
TOTAL: ~$20/month
```

---

## 📞 SUPPORT & MONITORING

```
AWS Console Dashboard
     │
     ├─ EC2 Instance Status
     │  └─ CPU: 5-15%
     │  └─ Memory: 30-40%
     │  └─ Network: Variable
     │
     ├─ RDS Database Status
     │  └─ CPU: 2-5%
     │  └─ Connections: 2-5
     │  └─ Storage: Growing
     │
     ├─ S3 Bucket Usage
     │  └─ Objects: ~100-1000
     │  └─ Storage: 100-500 MB
     │  └─ Requests: 1000s/day
     │
     └─ Billing Dashboard
        └─ Monthly Cost: $0
        └─ Budget Alert: $1
        └─ Forecast: $0
```

---

**This visual guide helps you understand the complete architecture!** 📊
